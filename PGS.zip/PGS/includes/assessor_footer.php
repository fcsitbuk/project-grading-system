<footer id="wif_footer">
				<p>&copy; <?php echo date('Y');?>. FCSIT all rights reserved.</p>
			</footer>  <!-- end of wif_footer -->