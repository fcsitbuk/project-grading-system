<nav class="left_nav" id="left_nav" title="powered by #teamSHM#">
	
	<div class="nav_link">
		
		<ul>
			
			<li><a href="coordinator"><span class="home">Dashboard</span></a></li>
			<li><a href="add_student"><span class="add_stud">Add Student</span></a></li>
			<li><a href="student_file"><span class="stud_file">Projects</span></a></li>
			<li><a href="defense_allocation"><span class="stud_list">Defense Allocation</span></a></li>
			<li><a href="coordinator?export=yes"><span class="stud_data">Export Scores</span></a></li>
			<li><a href="coordinator_key"><span class="key_mgr">Manage Password</span></a></li>
			<li><a href="includes/logout" title="logout"><span class="logout">Logout</span></a></li>
			
		</ul>
		
	</div>
	
</nav>