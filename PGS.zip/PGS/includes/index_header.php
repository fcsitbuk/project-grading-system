<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCSIT Project Manager</title>
    <link href="css/assessor_style.css" rel="stylesheet" />
    <link href="bt/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
	<link rel="shortcut icon" href="img/sys.ico">
    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="js/assessor_jv.js"></script>
    <script type="text/javascript" src="js/assessor_script.js"></script>
</head>

<body> 
<div id="theme"></div>
<div id="wrapper" style="background: none;">
	<div id="w_inner"> 
		
		<div id="wi_header"> 
			<header id="wih_header"> 
				<div id="wh_img">
                    <img src="img/buk.png" alt="buk"/>
                </div>
				<div class="wihh_name">
                    <h2><span class="wihhn_span">F</span>CSIT
                        <span class="wihhn_span">p</span>roject
                        <span class="wihhn_span">m</span>anager
                        
                    </h2>
                </div> <!-- end of wihh_name -->
                
			</header>  <!-- end of wih_header -->
		</div> <!-- end of wi_header -->