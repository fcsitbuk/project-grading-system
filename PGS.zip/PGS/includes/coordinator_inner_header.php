	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>FCSIT Project Manager</title>
    <link href="css/cordinator_style.css" rel="stylesheet" />
	<link rel="shortcut icon" href="img/sys.ico">
	<link href="css/font-awesome.min.css" rel="stylesheet" />
	<link href="css/coordinator_print.css" rel="stylesheet" media="print" />
    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
	