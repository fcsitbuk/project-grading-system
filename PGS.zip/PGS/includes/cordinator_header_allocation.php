<header>
		
	<div class="in_header">
		
		<div class="logo">
			
			<h2><span onclick="toggle_class()" class="menu_icon"></span><span class="header_icon"></span>FCSIT Project Manager</h2>
			
		</div>
		
		<div class="search_bar">
			
			
			
		</div>
		
		<p class="clear"></p>
		
	</div>
	
</header>