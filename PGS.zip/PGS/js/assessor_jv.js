function _(x){
	return document.getElementById(x);
	}